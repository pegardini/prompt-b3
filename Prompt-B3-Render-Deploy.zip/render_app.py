from flask import Flask, render_template_string, request, jsonify
from datetime import datetime, timedelta
import json
import os
import secrets
from pathlib import Path

app = Flask(__name__)

# Arquivo de banco de dados
DB_FILE = 'chaves.json'

# ==================== FUNÇÕES DE BANCO DE DADOS ====================

def carregar_chaves():
    """Carrega as chaves do arquivo JSON"""
    if os.path.exists(DB_FILE):
        with open(DB_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {'chaves': []}

def salvar_chaves(dados):
    """Salva as chaves no arquivo JSON"""
    with open(DB_FILE, 'w', encoding='utf-8') as f:
        json.dump(dados, f, ensure_ascii=False, indent=2)

def gerar_chave(tipo='trial'):
    """Gera uma chave única"""
    parte1 = secrets.token_hex(3).upper()
    parte2 = secrets.token_hex(3).upper()
    parte3 = secrets.token_hex(3).upper()
    
    if tipo == 'trial':
        return f"PROMPT-TRIAL-{parte1}-{parte2}-7DIAS"
    else:
        return f"PROMPT-PRO-{parte1}-{parte2}-1ANO"

def validar_chave(chave):
    """Valida se a chave é válida"""
    dados = carregar_chaves()
    
    for item in dados.get('chaves', []):
        if item['chave'] == chave:
            # Verifica se expirou
            data_expiracao = datetime.fromisoformat(item['data_expiracao'])
            if datetime.now() > data_expiracao:
                return {'valida': False, 'mensagem': 'Chave expirada'}
            
            # Verifica limite de dispositivos
            if item['dispositivos_usados'] >= item['dispositivos_permitidos']:
                return {'valida': False, 'mensagem': 'Limite de dispositivos atingido'}
            
            return {
                'valida': True,
                'email': item['email'],
                'tipo': item['tipo'],
                'data_expiracao': item['data_expiracao'],
                'mensagem': 'Chave válida!'
            }
    
    return {'valida': False, 'mensagem': 'Chave não encontrada'}

def criar_chave_novo(email, nome, tipo='trial'):
    """Cria uma nova chave"""
    dados = carregar_chaves()
    chave = gerar_chave(tipo)
    
    if tipo == 'trial':
        data_expiracao = (datetime.now() + timedelta(days=7)).isoformat()
        dispositivos = 1
    else:
        data_expiracao = (datetime.now() + timedelta(days=365)).isoformat()
        dispositivos = 2
    
    novo_item = {
        'chave': chave,
        'email': email,
        'nome': nome,
        'tipo': tipo,
        'data_criacao': datetime.now().isoformat(),
        'data_expiracao': data_expiracao,
        'dispositivos_permitidos': dispositivos,
        'dispositivos_usados': 0
    }
    
    dados['chaves'].append(novo_item)
    salvar_chaves(dados)
    
    return novo_item

# ==================== ROTAS ====================

@app.route('/')
def index():
    """Página principal com validação de chaves"""
    html = '''
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Prompt Fundamentalista B3 - Validação</title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                display: flex;
                justify-content: center;
                align-items: center;
                padding: 20px;
            }
            
            .container {
                background: white;
                border-radius: 15px;
                box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
                max-width: 500px;
                width: 100%;
                padding: 40px;
                animation: slideIn 0.5s ease-out;
            }
            
            @keyframes slideIn {
                from {
                    opacity: 0;
                    transform: translateY(-20px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            
            .header {
                text-align: center;
                margin-bottom: 30px;
            }
            
            .header h1 {
                color: #667eea;
                font-size: 28px;
                margin-bottom: 10px;
            }
            
            .header p {
                color: #666;
                font-size: 14px;
            }
            
            .form-group {
                margin-bottom: 20px;
            }
            
            label {
                display: block;
                margin-bottom: 8px;
                color: #333;
                font-weight: 600;
                font-size: 14px;
            }
            
            input {
                width: 100%;
                padding: 12px;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                font-size: 14px;
                transition: border-color 0.3s;
            }
            
            input:focus {
                outline: none;
                border-color: #667eea;
            }
            
            button {
                width: 100%;
                padding: 12px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                border: none;
                border-radius: 8px;
                font-size: 16px;
                font-weight: 600;
                cursor: pointer;
                transition: transform 0.2s;
            }
            
            button:hover {
                transform: translateY(-2px);
            }
            
            .resultado {
                margin-top: 20px;
                padding: 15px;
                border-radius: 8px;
                display: none;
                animation: fadeIn 0.3s ease-out;
            }
            
            @keyframes fadeIn {
                from {
                    opacity: 0;
                }
                to {
                    opacity: 1;
                }
            }
            
            .resultado.sucesso {
                background: #e8f5e9;
                border: 2px solid #4caf50;
                color: #2e7d32;
            }
            
            .resultado.erro {
                background: #ffebee;
                border: 2px solid #f44336;
                color: #c62828;
            }
            
            .prompt-container {
                margin-top: 30px;
                padding: 20px;
                background: #f5f5f5;
                border-radius: 8px;
                display: none;
            }
            
            .prompt-container h3 {
                color: #667eea;
                margin-bottom: 15px;
            }
            
            .prompt-text {
                background: white;
                padding: 15px;
                border-radius: 8px;
                max-height: 300px;
                overflow-y: auto;
                font-size: 12px;
                color: #333;
                margin-bottom: 15px;
                border: 1px solid #e0e0e0;
            }
            
            .copy-button {
                background: #4caf50;
                margin-bottom: 10px;
            }
            
            .copy-button:hover {
                background: #45a049;
            }
            
            .ia-buttons {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 10px;
                margin-top: 15px;
            }
            
            .ia-btn {
                padding: 10px;
                border: none;
                border-radius: 6px;
                color: white;
                cursor: pointer;
                font-size: 12px;
                font-weight: 600;
            }
            
            .claude-btn {
                background: #667eea;
            }
            
            .chatgpt-btn {
                background: #10a37f;
            }
            
            .gemini-btn {
                background: #4285f4;
            }
            
            .copilot-btn {
                background: #00a4ef;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🔐 Validação de Chave</h1>
                <p>Prompt Fundamentalista B3</p>
            </div>
            
            <form id="validacaoForm">
                <div class="form-group">
                    <label for="chave">Digite sua chave:</label>
                    <input type="text" id="chave" name="chave" placeholder="PROMPT-TRIAL-XXXXX-XXXXX-7DIAS" required>
                </div>
                
                <button type="submit">Validar Chave</button>
            </form>
            
            <div id="resultado" class="resultado"></div>
            
            <div id="promptContainer" class="prompt-container">
                <h3>✅ Acesso Liberado!</h3>
                <p style="margin-bottom: 15px; color: #666;">Escolha sua IA preferida e copie o prompt:</p>
                
                <button class="copy-button" onclick="copiarPrompt()">📋 Copiar Prompt</button>
                
                <div class="ia-buttons">
                    <button class="ia-btn claude-btn" onclick="abrirIA('claude')">🧠 Claude</button>
                    <button class="ia-btn chatgpt-btn" onclick="abrirIA('chatgpt')">💬 ChatGPT</button>
                    <button class="ia-btn gemini-btn" onclick="abrirIA('gemini')">🔮 Gemini</button>
                    <button class="ia-btn copilot-btn" onclick="abrirIA('copilot')">🚀 Copilot</button>
                </div>
            </div>
        </div>
        
        <script>
            const promptCompleto = `[AQUI VAI O PROMPT COMPLETO]`;
            
            document.getElementById('validacaoForm').addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const chave = document.getElementById('chave').value;
                const resultado = document.getElementById('resultado');
                
                try {
                    const response = await fetch('/api/validar', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ chave: chave })
                    });
                    
                    const data = await response.json();
                    
                    if (data.valida) {
                        resultado.className = 'resultado sucesso';
                        resultado.innerHTML = `✅ ${data.mensagem}<br>Email: ${data.email}`;
                        resultado.style.display = 'block';
                        document.getElementById('promptContainer').style.display = 'block';
                    } else {
                        resultado.className = 'resultado erro';
                        resultado.innerHTML = `❌ ${data.mensagem}`;
                        resultado.style.display = 'block';
                        document.getElementById('promptContainer').style.display = 'none';
                    }
                } catch (error) {
                    resultado.className = 'resultado erro';
                    resultado.innerHTML = `❌ Erro ao validar: ${error.message}`;
                    resultado.style.display = 'block';
                }
            });
            
            function copiarPrompt() {
                navigator.clipboard.writeText(promptCompleto);
                alert('✅ Prompt copiado para a área de transferência!');
            }
            
            function abrirIA(ia) {
                const urls = {
                    'claude': 'https://claude.ai',
                    'chatgpt': 'https://chat.openai.com',
                    'gemini': 'https://gemini.google.com',
                    'copilot': 'https://copilot.microsoft.com'
                };
                window.open(urls[ia], '_blank');
            }
        </script>
    </body>
    </html>
    '''
    return render_template_string(html)

@app.route('/api/validar', methods=['POST'])
def api_validar():
    """API para validar chaves"""
    data = request.get_json()
    chave = data.get('chave', '').strip()
    
    if not chave:
        return jsonify({'valida': False, 'mensagem': 'Chave não fornecida'})
    
    resultado = validar_chave(chave)
    return jsonify(resultado)

@app.route('/api/criar-chave', methods=['POST'])
def api_criar_chave():
    """API para criar nova chave (apenas para admin)"""
    data = request.get_json()
    email = data.get('email', '')
    nome = data.get('nome', '')
    tipo = data.get('tipo', 'trial')
    
    if not email or not nome:
        return jsonify({'sucesso': False, 'mensagem': 'Email e nome são obrigatórios'})
    
    novo_item = criar_chave_novo(email, nome, tipo)
    return jsonify({
        'sucesso': True,
        'chave': novo_item['chave'],
        'mensagem': 'Chave criada com sucesso!'
    })

@app.route('/health')
def health():
    """Health check para Render"""
    return jsonify({'status': 'ok'})

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=int(os.environ.get('PORT', 5000)))
